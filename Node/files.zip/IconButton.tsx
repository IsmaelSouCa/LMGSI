// Hito 2 — Paso 8: Componente reutilizable IconButton para favoritos

interface IconButtonProps {
  status: boolean;
  callback: () => void;
}

const IconButton = ({ status, callback }: IconButtonProps) => {
  return (
    <button
      onClick={callback}
      title={status ? 'Quitar de favoritos' : 'Añadir a favoritos'}
      className="transition-all duration-200 hover:scale-110 active:scale-95 cursor-pointer"
      style={{ background: 'none', border: 'none', padding: 0 }}
    >
      {status ? (
        // Estrella rellena — favorito activo (amarillo)
        <svg
          fill="#c9a84c"
          viewBox="-1 0 19 19"
          xmlns="http://www.w3.org/2000/svg"
          className="w-7 h-7"
          style={{ filter: 'drop-shadow(0 0 4px rgba(201,168,76,0.6))' }}
        >
          <path d="M16.417 9.583A7.917 7.917 0 1 1 8.5 1.666a7.917 7.917 0 0 1 7.917 7.917zm-3.08-1.993-1.472-.174-1.485-.176-1.247-2.704c-.345-.747-.908-.747-1.253 0L6.633 7.24l-1.485.176-1.471.174c-.817.097-.991.633-.387 1.192l1.088 1.006 1.098 1.015-.292 1.467-.289 1.453c-.16.807.296 1.138 1.014.737l2.598-1.455 2.598 1.455c.717.401 1.173.07 1.013-.737l-.58-2.92 1.097-1.015 1.089-1.006c.604-.559.43-1.095-.387-1.192z" />
        </svg>
      ) : (
        // Estrella vacía — no favorito (gris)
        <svg
          fill="#9ca3af"
          viewBox="-1 0 19 19"
          xmlns="http://www.w3.org/2000/svg"
          className="w-7 h-7 hover:fill-yellow-400 transition-colors"
        >
          <path d="M16.417 9.583A7.917 7.917 0 1 1 8.5 1.666a7.917 7.917 0 0 1 7.917 7.917zm-3.08-1.993-1.472-.174-1.485-.176-1.247-2.704c-.345-.747-.908-.747-1.253 0L6.633 7.24l-1.485.176-1.471.174c-.817.097-.991.633-.387 1.192l1.088 1.006 1.098 1.015-.292 1.467-.289 1.453c-.16.807.296 1.138 1.014.737l2.598-1.455 2.598 1.455c.717.401 1.173.07 1.013-.737l-.58-2.92 1.097-1.015 1.089-1.006c.604-.559.43-1.095-.387-1.192z" />
        </svg>
      )}
    </button>
  );
};

export default IconButton;
